import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Movie, sampleMovies } from '../data/sampleMovies';

interface MovieState {
  movies: Movie[];
  categories: string[];
  addMovie: (movie: Movie) => void;
  updateMovie: (id: string, movie: Partial<Movie>) => void;
  deleteMovie: (id: string) => void;
  initializeMovies: () => void;
}

export const useMovieStore = create<MovieState>()(
  persist(
    (set, get) => ({
      movies: [],
      categories: ['Trending', 'Latest', 'Top Rated'],
      addMovie: (movie) => set((state) => ({ movies: [...state.movies, movie] })),
      updateMovie: (id, updatedMovie) => 
        set((state) => ({
          movies: state.movies.map((m) => (m.id === id ? { ...m, ...updatedMovie } : m)),
        })),
      deleteMovie: (id) => 
        set((state) => ({
          movies: state.movies.filter((m) => m.id !== id),
        })),
      initializeMovies: () => {
        const { movies } = get();
        if (movies.length === 0) {
          set({ movies: sampleMovies });
        }
      },
    }),
    {
      name: 'movie-storage',
    }
  )
);
