import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface User {
  id: string;
  username: string;
  email?: string;
  password?: string;
  role: 'user' | 'admin';
  watchlist: string[]; // Movie IDs
  continueWatching: { movieId: string; progress: number }[];
}

interface AuthState {
  users: User[];
  currentUser: User | null;
  login: (username: string, password?: string) => boolean;
  register: (user: Omit<User, 'id' | 'watchlist' | 'continueWatching' | 'role'>) => boolean;
  logout: () => void;
  addToWatchlist: (movieId: string) => void;
  removeFromWatchlist: (movieId: string) => void;
  updateProgress: (movieId: string, progress: number) => void;
  initializeAdmin: () => void;
  deleteUser: (id: string) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      users: [],
      currentUser: null,
      login: (username, password) => {
        const { users } = get();
        const user = users.find((u) => u.username === username && u.password === password);
        if (user) {
          set({ currentUser: user });
          return true;
        }
        return false;
      },
      register: (newUserData) => {
        const { users } = get();
        if (users.find(u => u.username === newUserData.username)) {
          return false; // User exists
        }
        const newUser: User = {
          ...newUserData,
          id: Math.random().toString(36).substr(2, 9),
          role: 'user',
          watchlist: [],
          continueWatching: []
        };
        set({ users: [...users, newUser], currentUser: newUser });
        return true;
      },
      logout: () => set({ currentUser: null }),
      addToWatchlist: (movieId) => set((state) => {
        if (!state.currentUser) return state;
        const updatedUser = {
          ...state.currentUser,
          watchlist: [...state.currentUser.watchlist, movieId]
        };
        return {
          currentUser: updatedUser,
          users: state.users.map(u => u.id === updatedUser.id ? updatedUser : u)
        };
      }),
      removeFromWatchlist: (movieId) => set((state) => {
        if (!state.currentUser) return state;
        const updatedUser = {
          ...state.currentUser,
          watchlist: state.currentUser.watchlist.filter(id => id !== movieId)
        };
        return {
          currentUser: updatedUser,
          users: state.users.map(u => u.id === updatedUser.id ? updatedUser : u)
        };
      }),
      updateProgress: (movieId, progress) => set((state) => {
        if (!state.currentUser) return state;
        const existing = state.currentUser.continueWatching.find(cw => cw.movieId === movieId);
        let newCw;
        if (existing) {
          newCw = state.currentUser.continueWatching.map(cw => 
            cw.movieId === movieId ? { ...cw, progress } : cw
          );
        } else {
          newCw = [...state.currentUser.continueWatching, { movieId, progress }];
        }
        const updatedUser = { ...state.currentUser, continueWatching: newCw };
        return {
          currentUser: updatedUser,
          users: state.users.map(u => u.id === updatedUser.id ? updatedUser : u)
        };
      }),
      initializeAdmin: () => {
        const { users } = get();
        const adminExists = users.some(u => u.role === 'admin' && u.username === 'white');
        if (!adminExists) {
          const adminUser: User = {
            id: 'admin-1',
            username: 'white',
            password: 'white subham 123',
            role: 'admin',
            watchlist: [],
            continueWatching: []
          };
          set({ users: [...users, adminUser] });
        }
      },
      deleteUser: (id) => set((state) => ({
        users: state.users.filter(u => u.id !== id && u.role !== 'admin')
      }))
    }),
    {
      name: 'auth-storage',
    }
  )
);
