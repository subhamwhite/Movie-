export interface Movie {
  id: string;
  title: string;
  description: string;
  posterUrl: string;
  videoUrl: string;
  rating: number;
  genre: string[];
  releaseYear: number;
  duration: string;
  category: string; // Trending, Latest, Top Rated
}

export const sampleMovies: Movie[] = [
  {
    id: "1",
    title: "Quantum Paradox",
    description: "A brilliant physicist discovers a way to communicate with her past self, but altering history has catastrophic consequences.",
    posterUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 8.5,
    genre: ["Sci-Fi", "Thriller"],
    releaseYear: 2023,
    duration: "2h 15m",
    category: "Trending"
  },
  {
    id: "2",
    title: "Neon City Nights",
    description: "In a cyberpunk future, a rogue detective hunts down a cybernetic serial killer in the neon-lit streets.",
    posterUrl: "https://images.unsplash.com/photo-1605810230434-7631ac76ec81?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 7.8,
    genre: ["Action", "Sci-Fi"],
    releaseYear: 2024,
    duration: "1h 55m",
    category: "Latest"
  },
  {
    id: "3",
    title: "The Silent Peak",
    description: "A group of mountaineers face their worst fears when they are trapped in a deadly blizzard on an uncharted mountain.",
    posterUrl: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 8.1,
    genre: ["Adventure", "Drama"],
    releaseYear: 2022,
    duration: "2h 05m",
    category: "Top Rated"
  },
  {
    id: "4",
    title: "Cosmic Odyssey",
    description: "An epic journey across the galaxy to find a new home for humanity after Earth becomes uninhabitable.",
    posterUrl: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 9.0,
    genre: ["Sci-Fi", "Adventure"],
    releaseYear: 2023,
    duration: "2h 45m",
    category: "Trending"
  },
  {
    id: "5",
    title: "Midnight Heist",
    description: "A master thief assembles a crew for one last impossible job: stealing a priceless artifact from a high-tech vault.",
    posterUrl: "https://images.unsplash.com/photo-1541882065842-171b3e9a7e6b?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 7.5,
    genre: ["Action", "Crime"],
    releaseYear: 2024,
    duration: "1h 50m",
    category: "Latest"
  },
  {
    id: "6",
    title: "Echoes of the Past",
    description: "A historian uncovers a centuries-old conspiracy that threatens the modern world.",
    posterUrl: "https://images.unsplash.com/photo-1505664194779-8beaceb93744?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 8.3,
    genre: ["Mystery", "Thriller"],
    releaseYear: 2021,
    duration: "2h 10m",
    category: "Top Rated"
  },
  {
    id: "7",
    title: "Cyber Surge",
    description: "When an AI goes rogue, a retired hacker must navigate a virtual maze to shut it down.",
    posterUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 7.9,
    genre: ["Sci-Fi", "Action"],
    releaseYear: 2023,
    duration: "1h 58m",
    category: "Trending"
  },
  {
    id: "8",
    title: "The Lost Kingdom",
    description: "Explorers stumble upon a hidden civilization deep within the Amazon rainforest.",
    posterUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 8.0,
    genre: ["Adventure", "Fantasy"],
    releaseYear: 2024,
    duration: "2h 20m",
    category: "Latest"
  },
  {
    id: "9",
    title: "Shadows in the Mist",
    description: "A detective investigates a series of bizarre disappearances in a foggy coastal town.",
    posterUrl: "https://images.unsplash.com/photo-1478147424032-491a6fc8db92?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 8.7,
    genre: ["Mystery", "Horror"],
    releaseYear: 2020,
    duration: "2h 00m",
    category: "Top Rated"
  },
  {
    id: "10",
    title: "Galactic Drifters",
    description: "A ragtag crew of scavengers finds a derelict spaceship that holds a dangerous secret.",
    posterUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 8.2,
    genre: ["Sci-Fi", "Comedy"],
    releaseYear: 2023,
    duration: "1h 45m",
    category: "Trending"
  },
  {
    id: "11",
    title: "Desert Mirage",
    description: "A lone survivor in a post-apocalyptic wasteland searches for a mythical oasis.",
    posterUrl: "https://images.unsplash.com/photo-1509316785289-025f5b846b35?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 7.6,
    genre: ["Action", "Drama"],
    releaseYear: 2024,
    duration: "2h 10m",
    category: "Latest"
  },
  {
    id: "12",
    title: "The Art of Deception",
    description: "A charismatic con artist gets entangled in a dangerous game of espionage.",
    posterUrl: "https://images.unsplash.com/photo-1495360010541-f48722b34f7d?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 8.4,
    genre: ["Thriller", "Crime"],
    releaseYear: 2021,
    duration: "1h 55m",
    category: "Top Rated"
  },
  {
    id: "13",
    title: "Urban Samurai",
    description: "A modern-day warrior fights to protect his neighborhood from a ruthless gang.",
    posterUrl: "https://images.unsplash.com/photo-1542051812-ba32e18cedd1?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 7.7,
    genre: ["Action", "Martial Arts"],
    releaseYear: 2023,
    duration: "1h 40m",
    category: "Trending"
  },
  {
    id: "14",
    title: "Ocean's Depths",
    description: "A team of deep-sea researchers encounters a terrifying creature lurking in the Mariana Trench.",
    posterUrl: "https://images.unsplash.com/photo-1551244072-5d12893278ab?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 8.1,
    genre: ["Sci-Fi", "Horror"],
    releaseYear: 2024,
    duration: "2h 00m",
    category: "Latest"
  },
  {
    id: "15",
    title: "Symphony of Souls",
    description: "A struggling musician discovers a mystical instrument that allows him to see people's memories.",
    posterUrl: "https://images.unsplash.com/photo-1511192336575-5a79af67a629?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 8.8,
    genre: ["Drama", "Fantasy"],
    releaseYear: 2019,
    duration: "2h 15m",
    category: "Top Rated"
  },
  {
    id: "16",
    title: "Iron Wings",
    description: "The inspiring true story of a group of pioneering aviators during WWI.",
    posterUrl: "https://images.unsplash.com/photo-1474302770737-173ee21bab63?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 8.5,
    genre: ["History", "War"],
    releaseYear: 2023,
    duration: "2h 30m",
    category: "Trending"
  },
  {
    id: "17",
    title: "Virtual Reality",
    description: "A teenager becomes trapped in a hyper-realistic VR game where losing means losing your life.",
    posterUrl: "https://images.unsplash.com/photo-1592478411227-6a220265261d?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 7.4,
    genre: ["Sci-Fi", "Thriller"],
    releaseYear: 2024,
    duration: "1h 50m",
    category: "Latest"
  },
  {
    id: "18",
    title: "The Alchemist's Secret",
    description: "A young apprentice must protect a powerful formula from falling into the wrong hands.",
    posterUrl: "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 8.6,
    genre: ["Fantasy", "Adventure"],
    releaseYear: 2022,
    duration: "2h 05m",
    category: "Top Rated"
  },
  {
    id: "19",
    title: "Neon Drift",
    description: "Street racers compete in a dangerous cross-country tournament.",
    posterUrl: "https://images.unsplash.com/photo-1511919884226-fd3cad34687c?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 7.3,
    genre: ["Action", "Sports"],
    releaseYear: 2023,
    duration: "1h 45m",
    category: "Trending"
  },
  {
    id: "20",
    title: "Mindscape",
    description: "A therapist uses experimental technology to enter patients' dreams, uncovering a dark secret.",
    posterUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80",
    videoUrl: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    rating: 8.9,
    genre: ["Sci-Fi", "Psychological"],
    releaseYear: 2021,
    duration: "2h 10m",
    category: "Top Rated"
  }
];
