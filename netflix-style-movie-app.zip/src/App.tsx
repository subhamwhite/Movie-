import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import { useAuthStore } from './store/useAuthStore';
import { useMovieStore } from './store/useMovieStore';

import Layout from './components/Layout';
import AdminLayout from './components/admin/AdminLayout';

import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Profile from './pages/Profile';
import Watch from './pages/Watch';

import AdminLogin from './pages/admin/AdminLogin';
import Dashboard from './pages/admin/Dashboard';
import ManageMovies from './pages/admin/ManageMovies';
import ManageUsers from './pages/admin/ManageUsers';

function ProtectedRoute({ children, requireAdmin = false }: { children: React.ReactNode, requireAdmin?: boolean }) {
  const currentUser = useAuthStore(state => state.currentUser);
  
  if (!currentUser) return <Navigate to="/login" replace />;
  if (requireAdmin && currentUser.role !== 'admin') return <Navigate to="/" replace />;
  
  return <>{children}</>;
}

export default function App() {
  const initializeAdmin = useAuthStore(state => state.initializeAdmin);
  const initializeMovies = useMovieStore(state => state.initializeMovies);

  useEffect(() => {
    initializeAdmin();
    initializeMovies();
  }, [initializeAdmin, initializeMovies]);

  return (
    <Router>
      <Toaster position="top-right" toastOptions={{ style: { background: '#18181b', color: '#fff' } }} />
      <Routes>
        <Route path="/admin/login" element={<AdminLogin />} />
        
        <Route path="/admin" element={<ProtectedRoute requireAdmin><AdminLayout /></ProtectedRoute>}>
          <Route index element={<Navigate to="/admin/dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="movies" element={<ManageMovies />} />
          <Route path="users" element={<ManageUsers />} />
        </Route>

        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="login" element={<Login />} />
          <Route path="register" element={<Register />} />
          <Route path="profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
          <Route path="watch/:id" element={<ProtectedRoute><Watch /></ProtectedRoute>} />
        </Route>
      </Routes>
    </Router>
  );
}
