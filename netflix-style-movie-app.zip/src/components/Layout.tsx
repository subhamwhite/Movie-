import { Outlet, Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/useAuthStore';
import { LogOut, User, Search, Play, Menu, X } from 'lucide-react';
import { useState, useEffect } from 'react';
import { cn } from '../lib/utils';

export default function Layout() {
  const { currentUser, logout } = useAuthStore();
  const navigate = useNavigate();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen flex flex-col bg-zinc-950">
      <header className={cn("fixed top-0 w-full z-50 transition-all duration-300", isScrolled ? "bg-zinc-950/90 backdrop-blur-md shadow-lg" : "bg-gradient-to-b from-black/80 to-transparent")}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Link to="/" className="flex items-center gap-2">
                <Play className="w-8 h-8 text-red-600 fill-red-600" />
                <span className="text-2xl font-bold text-red-600 tracking-tighter">NETFLIX</span>
              </Link>
              <nav className="hidden md:ml-10 md:flex items-center space-x-6">
                <Link to="/" className="text-sm font-medium text-zinc-300 hover:text-white transition">Home</Link>
                <Link to="/#trending" className="text-sm font-medium text-zinc-300 hover:text-white transition">Trending</Link>
                <Link to="/#latest" className="text-sm font-medium text-zinc-300 hover:text-white transition">Latest</Link>
              </nav>
            </div>

            <div className="hidden md:flex items-center gap-4">
              {/* Search Implementation */}
              <div className="relative group">
                <Search className="w-5 h-5 text-white absolute left-3 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity" />
                <input 
                  type="text" 
                  placeholder="Search movies..."
                  className="w-8 cursor-pointer focus:w-64 focus:cursor-text group-hover:w-64 group-hover:cursor-text bg-transparent focus:bg-black/50 group-hover:bg-black/50 border border-transparent focus:border-white group-hover:border-white rounded px-3 py-1.5 focus:pl-10 group-hover:pl-10 text-white text-sm transition-all duration-300 outline-none placeholder:text-transparent focus:placeholder:text-zinc-400 group-hover:placeholder:text-zinc-400"
                  onChange={(e) => {
                    const evt = new CustomEvent('navbarSearch', { detail: e.target.value });
                    window.dispatchEvent(evt);
                  }}
                />
              </div>

              {currentUser ? (
                <>
                  <Link to="/profile" className="flex items-center gap-2 text-zinc-300 hover:text-white transition">
                    <User className="w-5 h-5" />
                    <span className="text-sm font-medium">{currentUser.username}</span>
                  </Link>
                  {currentUser.role === 'admin' && (
                    <Link to="/admin" className="text-xs font-semibold bg-red-600 text-white px-2 py-1 rounded">Admin</Link>
                  )}
                  <button onClick={handleLogout} className="text-zinc-300 hover:text-white transition">
                    <LogOut className="w-5 h-5" />
                  </button>
                </>
              ) : (
                <div className="flex gap-4">
                  <Link to="/login" className="text-sm font-medium text-zinc-300 hover:text-white transition flex items-center">Sign In</Link>
                  <Link to="/register" className="text-sm font-medium bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition">Sign Up</Link>
                </div>
              )}
            </div>

            <div className="md:hidden flex items-center">
              <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="text-zinc-300 hover:text-white">
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-40 bg-zinc-950 pt-20 px-4">
          <div className="flex flex-col space-y-4">
            <Link to="/" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium">Home</Link>
            {currentUser ? (
              <>
                <Link to="/profile" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium">Profile</Link>
                {currentUser.role === 'admin' && (
                  <Link to="/admin" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium text-red-500">Admin Panel</Link>
                )}
                <button onClick={() => { handleLogout(); setMobileMenuOpen(false); }} className="text-left text-lg font-medium text-zinc-400">Logout</button>
              </>
            ) : (
              <>
                <Link to="/login" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium">Sign In</Link>
                <Link to="/register" onClick={() => setMobileMenuOpen(false)} className="text-lg font-medium text-red-500">Sign Up</Link>
              </>
            )}
          </div>
        </div>
      )}

      <main className="flex-grow pb-16">
        <Outlet />
      </main>

      <footer className="bg-zinc-950 border-t border-zinc-900 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-zinc-500 text-sm">
          <p>&copy; {new Date().getFullYear()} Netflix Clone. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
