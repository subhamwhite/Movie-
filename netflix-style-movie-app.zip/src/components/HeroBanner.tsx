import { useState } from 'react';
import { Play, Info } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Movie } from '../data/sampleMovies';
import MovieDetailsModal from './MovieDetailsModal';

interface HeroBannerProps {
  movie: Movie;
}

export default function HeroBanner({ movie }: HeroBannerProps) {
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(false);

  return (
    <div className="relative h-[80vh] w-full">
      <div className="absolute inset-0">
        <img 
          src={movie.posterUrl} 
          alt={movie.title} 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-transparent" />
      </div>

      <div className="relative h-full flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-2xl space-y-6">
            <h1 className="text-5xl md:text-7xl font-bold text-white tracking-tight drop-shadow-lg">
              {movie.title}
            </h1>
            
            <div className="flex items-center gap-4 text-sm font-medium text-zinc-300 drop-shadow-md">
              <span className="text-green-500 font-bold">{Math.round(movie.rating * 10)}% Match</span>
              <span>{movie.releaseYear}</span>
              <span className="px-2 py-0.5 border border-zinc-600 rounded">{movie.duration}</span>
              <span className="px-2 py-0.5 border border-zinc-600 rounded bg-zinc-800/50">HD</span>
            </div>

            <p className="text-lg text-zinc-200 drop-shadow-md max-w-xl line-clamp-3">
              {movie.description}
            </p>

            <div className="flex items-center gap-4 pt-4">
              <button 
                onClick={() => navigate(`/watch/${movie.id}`)}
                className="flex items-center gap-2 bg-white text-black px-6 py-3 rounded hover:bg-zinc-200 transition font-bold text-lg"
              >
                <Play className="w-6 h-6 fill-black" />
                Play
              </button>
              <button 
                onClick={() => setShowModal(true)}
                className="flex items-center gap-2 bg-zinc-500/50 hover:bg-zinc-500/70 text-white px-6 py-3 rounded transition font-bold text-lg backdrop-blur-sm"
              >
                <Info className="w-6 h-6" />
                More Info
              </button>
            </div>
          </div>
        </div>
      </div>

      {showModal && <MovieDetailsModal movie={movie} onClose={() => setShowModal(false)} />}
    </div>
  );
}
