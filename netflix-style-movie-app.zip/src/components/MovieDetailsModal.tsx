import { Play, Plus, X, Check, ThumbsUp } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Movie } from '../data/sampleMovies';
import { useAuthStore } from '../store/useAuthStore';
import toast from 'react-hot-toast';

interface MovieDetailsModalProps {
  movie: Movie;
  onClose: () => void;
}

export default function MovieDetailsModal({ movie, onClose }: MovieDetailsModalProps) {
  const navigate = useNavigate();
  const { currentUser, addToWatchlist, removeFromWatchlist } = useAuthStore();
  
  const inWatchlist = currentUser?.watchlist.includes(movie.id);

  const handleWatchlist = () => {
    if (!currentUser) {
      toast.error('Please login to use watchlist');
      navigate('/login');
      return;
    }
    
    if (inWatchlist) {
      removeFromWatchlist(movie.id);
      toast.success('Removed from watchlist');
    } else {
      addToWatchlist(movie.id);
      toast.success('Added to watchlist');
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      />
      
      <div className="relative bg-zinc-900 w-full max-w-4xl rounded-xl overflow-hidden shadow-2xl z-10 animate-in fade-in zoom-in duration-200 h-[90vh] sm:h-auto flex flex-col">
        {/* Banner Section */}
        <div className="relative h-[40vh] sm:h-[50vh] w-full shrink-0">
          <img 
            src={movie.posterUrl} 
            alt={movie.title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-900 via-zinc-900/40 to-transparent" />
          
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 bg-zinc-900/80 hover:bg-white hover:text-black text-white p-2 rounded-full transition-colors backdrop-blur-sm z-20"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="absolute bottom-0 left-0 p-6 sm:p-8 w-full">
            <h2 className="text-3xl sm:text-5xl font-bold text-white mb-4 drop-shadow-lg">{movie.title}</h2>
            <div className="flex flex-wrap items-center gap-3">
              <button 
                onClick={() => { onClose(); navigate(`/watch/${movie.id}`); }}
                className="flex items-center gap-2 bg-white text-black px-6 py-2 sm:py-3 rounded hover:bg-zinc-200 transition font-bold"
              >
                <Play className="w-5 h-5 sm:w-6 sm:h-6 fill-black" />
                Play
              </button>
              <button 
                onClick={handleWatchlist}
                className="flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 bg-zinc-800/80 hover:bg-zinc-700 text-white rounded-full transition border border-zinc-600 backdrop-blur-sm"
                title={inWatchlist ? "Remove from watchlist" : "Add to watchlist"}
              >
                {inWatchlist ? <Check className="w-5 h-5 sm:w-6 sm:h-6" /> : <Plus className="w-5 h-5 sm:w-6 sm:h-6" />}
              </button>
              <button 
                className="flex items-center justify-center w-10 h-10 sm:w-12 sm:h-12 bg-zinc-800/80 hover:bg-zinc-700 text-white rounded-full transition border border-zinc-600 backdrop-blur-sm"
                title="Rate"
              >
                <ThumbsUp className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>
            </div>
          </div>
        </div>

        {/* Details Section */}
        <div className="p-6 sm:p-8 overflow-y-auto flex-1">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2 space-y-4">
              <div className="flex flex-wrap items-center gap-3 text-sm font-medium text-zinc-300">
                <span className="text-green-500 font-bold">{Math.round(movie.rating * 10)}% Match</span>
                <span>{movie.releaseYear}</span>
                <span className="px-2 py-0.5 border border-zinc-600 rounded">{movie.duration}</span>
                <span className="px-2 py-0.5 border border-zinc-600 rounded bg-zinc-800">HD</span>
              </div>
              <p className="text-base sm:text-lg text-zinc-300 leading-relaxed">
                {movie.description}
              </p>
            </div>
            
            <div className="space-y-4 text-sm">
              <div>
                <span className="text-zinc-500 block mb-1">Genres</span>
                <div className="flex flex-wrap gap-2">
                  {movie.genre.map(g => (
                    <span key={g} className="text-white bg-zinc-800 px-2 py-1 rounded">{g}</span>
                  ))}
                </div>
              </div>
              <div>
                <span className="text-zinc-500 block mb-1">Category</span>
                <span className="text-white">{movie.category}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
