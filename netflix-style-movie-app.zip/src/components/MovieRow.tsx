import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useRef, useState } from 'react';
import { Movie } from '../data/sampleMovies';
import MovieCard from './MovieCard';
import { cn } from '../lib/utils';

interface MovieRowProps {
  title: string;
  movies: Movie[];
  id?: string;
}

export default function MovieRow({ title, movies, id }: MovieRowProps) {
  const rowRef = useRef<HTMLDivElement>(null);
  const [isScrolled, setIsScrolled] = useState(false);

  const handleScroll = (direction: 'left' | 'right') => {
    if (rowRef.current) {
      const { scrollLeft, clientWidth } = rowRef.current;
      const scrollTo = direction === 'left' ? scrollLeft - clientWidth : scrollLeft + clientWidth;
      rowRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  const onScroll = () => {
    if (rowRef.current) {
      setIsScrolled(rowRef.current.scrollLeft > 0);
    }
  };

  if (movies.length === 0) return null;

  return (
    <div id={id} className="space-y-2 py-4 relative group">
      <h2 className="text-xl md:text-2xl font-bold text-zinc-100 px-4 md:px-12">{title}</h2>
      
      <div className="relative">
        <button 
          onClick={() => handleScroll('left')}
          className={cn("absolute left-0 top-0 bottom-0 z-40 w-12 bg-black/50 hover:bg-black/80 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity disabled:opacity-0", !isScrolled && "hidden")}
        >
          <ChevronLeft className="w-8 h-8" />
        </button>

        <div 
          ref={rowRef}
          onScroll={onScroll}
          className="flex items-center gap-4 overflow-x-auto scrollbar-hide px-4 md:px-12 pb-8 pt-4 scroll-smooth"
        >
          {movies.map((movie) => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>

        <button 
          onClick={() => handleScroll('right')}
          className="absolute right-0 top-0 bottom-0 z-40 w-12 bg-black/50 hover:bg-black/80 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <ChevronRight className="w-8 h-8" />
        </button>
      </div>
    </div>
  );
}
