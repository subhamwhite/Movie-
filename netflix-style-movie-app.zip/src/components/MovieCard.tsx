import { useState } from 'react';
import { Play, Plus, Check, ChevronDown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Movie } from '../data/sampleMovies';
import { useAuthStore } from '../store/useAuthStore';
import toast from 'react-hot-toast';
import MovieDetailsModal from './MovieDetailsModal';

interface MovieCardProps {
  movie: Movie;
}

export default function MovieCard({ movie }: MovieCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const navigate = useNavigate();
  const { currentUser, addToWatchlist, removeFromWatchlist } = useAuthStore();
  
  const inWatchlist = currentUser?.watchlist.includes(movie.id);

  const handleWatchlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentUser) {
      toast.error('Please login to use watchlist');
      navigate('/login');
      return;
    }
    
    if (inWatchlist) {
      removeFromWatchlist(movie.id);
      toast.success('Removed from watchlist');
    } else {
      addToWatchlist(movie.id);
      toast.success('Added to watchlist');
    }
  };

  return (
    <>
      <div 
        className="relative flex-none w-[160px] sm:w-[200px] md:w-[240px] aspect-[2/3] rounded-md transition-transform duration-300 ease-out origin-center cursor-pointer group"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onClick={() => setShowModal(true)}
      >
        <img 
          src={movie.posterUrl} 
          alt={movie.title} 
          className="w-full h-full object-cover rounded-md shadow-lg"
          loading="lazy"
        />

        {/* Hover Card */}
        {isHovered && (
          <div className="absolute top-0 left-0 w-full z-30 scale-125 transition-transform duration-300 bg-zinc-900 rounded-md shadow-2xl animate-in fade-in zoom-in-95 origin-center">
            <div className="relative aspect-[16/9] w-full">
              <img 
                src={movie.posterUrl} 
                alt={movie.title} 
                className="w-full h-full object-cover rounded-t-md"
              />
              <div className="absolute inset-0 bg-black/20" />
            </div>
            
            <div className="p-3 space-y-2">
              <div className="flex items-center gap-2">
                <button 
                  onClick={(e) => { e.stopPropagation(); navigate(`/watch/${movie.id}`); }}
                  className="w-8 h-8 flex items-center justify-center bg-white text-black rounded-full hover:bg-zinc-200 transition"
                  title="Play"
                >
                  <Play className="w-4 h-4 fill-black ml-0.5" />
                </button>
                <button 
                  onClick={handleWatchlist}
                  className="w-8 h-8 flex items-center justify-center bg-zinc-800 text-white border border-zinc-600 rounded-full hover:bg-zinc-700 transition"
                  title={inWatchlist ? "Remove from watchlist" : "Add to watchlist"}
                >
                  {inWatchlist ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); setShowModal(true); }}
                  className="w-8 h-8 flex items-center justify-center bg-zinc-800 text-white border border-zinc-600 rounded-full hover:bg-zinc-700 transition ml-auto"
                  title="More Info"
                >
                  <ChevronDown className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center gap-2 text-[10px] sm:text-xs font-semibold">
                <span className="text-green-500">{Math.round(movie.rating * 10)}% Match</span>
                <span className="border border-zinc-600 px-1 rounded text-zinc-400">{movie.duration}</span>
                <span className="text-zinc-400">{movie.releaseYear}</span>
              </div>
              
              <div className="flex items-center gap-1.5 flex-wrap">
                {movie.genre.slice(0, 3).map((g, i) => (
                  <span key={g} className="text-[10px] text-zinc-300 flex items-center">
                    {g}
                    {i < Math.min(movie.genre.length, 3) - 1 && <span className="w-1 h-1 bg-zinc-600 rounded-full mx-1.5 inline-block" />}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {showModal && <MovieDetailsModal movie={movie} onClose={() => setShowModal(false)} />}
    </>
  );
}
