import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuthStore } from '../store/useAuthStore';
import toast from 'react-hot-toast';

export default function Register() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  const register = useAuthStore(state => state.register);
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (password.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }

    const success = register({ username, email, password });
    
    if (success) {
      toast.success('Registration successful!');
      navigate('/');
    } else {
      toast.error('Username already exists');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=1920&q=80" 
          alt="Background" 
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-black/60" />
      </div>

      <div className="relative z-10 w-full max-w-md p-8 bg-black/80 rounded-lg shadow-2xl backdrop-blur-sm border border-zinc-800 m-4">
        <h2 className="text-3xl font-bold text-white mb-8">Sign Up</h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <input
              type="text"
              required
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-700 rounded p-4 text-white placeholder-zinc-400 focus:outline-none focus:border-white transition-colors"
            />
          </div>
          <div>
            <input
              type="email"
              required
              placeholder="Email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-700 rounded p-4 text-white placeholder-zinc-400 focus:outline-none focus:border-white transition-colors"
            />
          </div>
          <div>
            <input
              type="password"
              required
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-700 rounded p-4 text-white placeholder-zinc-400 focus:outline-none focus:border-white transition-colors"
            />
          </div>
          
          <button
            type="submit"
            className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-4 rounded transition-colors"
          >
            Sign Up
          </button>
        </form>

        <div className="mt-8 text-zinc-400">
          Already have an account? <Link to="/login" className="text-white hover:underline">Sign in now</Link>.
        </div>
      </div>
    </div>
  );
}
