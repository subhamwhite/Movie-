import { useEffect, useState } from 'react';
import { useMovieStore } from '../store/useMovieStore';
import { useAuthStore } from '../store/useAuthStore';
import HeroBanner from '../components/HeroBanner';
import MovieRow from '../components/MovieRow';

export default function Home() {
  const movies = useMovieStore(state => state.movies);
  const currentUser = useAuthStore(state => state.currentUser);
  const [heroMovie, setHeroMovie] = useState<any>(null);

  useEffect(() => {
    if (movies.length > 0 && !heroMovie) {
      const trending = movies.filter(m => m.category === 'Trending');
      if (trending.length > 0) {
        setHeroMovie(trending[Math.floor(Math.random() * trending.length)]);
      } else {
        setHeroMovie(movies[0]);
      }
    }
  }, [movies, heroMovie]);

  const trendingMovies = movies.filter(m => m.category === 'Trending');
  const latestMovies = movies.filter(m => m.category === 'Latest');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const handleSearch = (e: CustomEvent<string>) => setSearchQuery(e.detail);
    window.addEventListener('navbarSearch', handleSearch as EventListener);
    return () => window.removeEventListener('navbarSearch', handleSearch as EventListener);
  }, []);

  const searchResults = searchQuery 
    ? movies.filter(m => m.title.toLowerCase().includes(searchQuery.toLowerCase()) || m.genre.some(g => g.toLowerCase().includes(searchQuery.toLowerCase())))
    : [];

  const topRatedMovies = movies.filter(m => m.category === 'Top Rated');
  
  const watchlistMovies = currentUser ? movies.filter(m => currentUser.watchlist.includes(m.id)) : [];
  const continueWatchingMovies = currentUser 
    ? movies.filter(m => currentUser.continueWatching.some(cw => cw.movieId === m.id)) 
    : [];

  if (searchQuery) {
    return (
      <div className="bg-zinc-950 min-h-screen pt-24 pb-20 px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl font-bold text-white mb-6">Search Results for "{searchQuery}"</h2>
        {searchResults.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {searchResults.map(movie => (
              <div key={movie.id} className="relative aspect-[2/3] w-full max-w-[200px] mx-auto">
                <img src={movie.posterUrl} alt={movie.title} className="w-full h-full object-cover rounded-md" />
                <div className="absolute inset-0 bg-black/60 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                  <button onClick={() => window.location.href = `/watch/${movie.id}`} className="bg-white text-black px-4 py-2 rounded font-bold text-sm">Play</button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 text-zinc-500 text-lg">No movies found matching "{searchQuery}"</div>
        )}
      </div>
    );
  }

  return (
    <div className="bg-zinc-950 pb-20">
      {heroMovie && <HeroBanner movie={heroMovie} />}
      
      <div className="relative z-20 -mt-32 space-y-8">
        {currentUser && continueWatchingMovies.length > 0 && (
          <MovieRow title="Continue Watching" movies={continueWatchingMovies} />
        )}
        
        <MovieRow id="trending" title="Trending Now" movies={trendingMovies} />
        
        {currentUser && watchlistMovies.length > 0 && (
          <MovieRow title="My List" movies={watchlistMovies} />
        )}
        
        <MovieRow id="latest" title="Latest Releases" movies={latestMovies} />
        <MovieRow title="Top Rated" movies={topRatedMovies} />
      </div>
    </div>
  );
}
