import { useAuthStore } from '../store/useAuthStore';
import { useMovieStore } from '../store/useMovieStore';
import { User as UserIcon, Settings, Clock, List, LogOut } from 'lucide-react';
import MovieRow from '../components/MovieRow';

export default function Profile() {
  const { currentUser, logout } = useAuthStore();
  const movies = useMovieStore(state => state.movies);

  if (!currentUser) return null;

  const watchlistMovies = movies.filter(m => currentUser.watchlist.includes(m.id));
  const continueWatchingMovies = movies.filter(m => currentUser.continueWatching.some(cw => cw.movieId === m.id));

  return (
    <div className="bg-zinc-950 min-h-screen pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden mb-12">
          <div className="p-8 sm:p-12 flex flex-col md:flex-row items-center gap-8 border-b border-zinc-800">
            <div className="w-32 h-32 bg-red-600/20 rounded-full flex items-center justify-center border-4 border-red-500 shrink-0">
              <UserIcon className="w-16 h-16 text-red-500" />
            </div>
            <div className="text-center md:text-left flex-1">
              <h1 className="text-4xl font-bold text-white mb-2">{currentUser.username}</h1>
              <p className="text-zinc-400 text-lg mb-4">{currentUser.email || 'No email provided'}</p>
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-4">
                <span className="px-3 py-1 bg-zinc-800 rounded-full text-sm font-medium text-white flex items-center gap-2">
                  <List className="w-4 h-4" /> {currentUser.watchlist.length} in List
                </span>
                <span className="px-3 py-1 bg-zinc-800 rounded-full text-sm font-medium text-white flex items-center gap-2">
                  <Clock className="w-4 h-4" /> {currentUser.continueWatching.length} watching
                </span>
                {currentUser.role === 'admin' && (
                  <span className="px-3 py-1 bg-red-600/20 text-red-500 border border-red-500/50 rounded-full text-sm font-medium flex items-center gap-2">
                    Admin Privileges
                  </span>
                )}
              </div>
            </div>
            <div className="flex flex-col gap-3 shrink-0 w-full md:w-auto">
              <button className="flex items-center justify-center gap-2 bg-zinc-800 hover:bg-zinc-700 text-white px-6 py-3 rounded-lg transition-colors font-medium">
                <Settings className="w-5 h-5" />
                Manage Profile
              </button>
              <button onClick={() => { logout(); window.location.href = '/'; }} className="flex items-center justify-center gap-2 bg-red-600/10 hover:bg-red-600/20 text-red-500 px-6 py-3 rounded-lg transition-colors font-medium border border-red-500/20">
                <LogOut className="w-5 h-5" />
                Sign Out
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-12">
          {continueWatchingMovies.length > 0 && (
            <div>
              <div className="flex items-center gap-3 mb-6 px-4 md:px-12">
                <Clock className="w-6 h-6 text-red-500" />
                <h2 className="text-2xl font-bold text-white">Continue Watching</h2>
              </div>
              <div className="-mx-4 md:-mx-12">
                <MovieRow title="" movies={continueWatchingMovies} />
              </div>
            </div>
          )}

          {watchlistMovies.length > 0 ? (
            <div>
              <div className="flex items-center gap-3 mb-6 px-4 md:px-12">
                <List className="w-6 h-6 text-red-500" />
                <h2 className="text-2xl font-bold text-white">My List</h2>
              </div>
              <div className="-mx-4 md:-mx-12">
                <MovieRow title="" movies={watchlistMovies} />
              </div>
            </div>
          ) : (
            <div className="text-center py-20 bg-zinc-900 border border-zinc-800 rounded-xl">
              <List className="w-16 h-16 text-zinc-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-white mb-2">Your List is Empty</h3>
              <p className="text-zinc-400">Add shows and movies to your list to watch them later.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
