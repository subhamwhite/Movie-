import { useAuthStore } from '../../store/useAuthStore';
import { useMovieStore } from '../../store/useMovieStore';
import { Users, Film, PlayCircle, Clock } from 'lucide-react';

export default function Dashboard() {
  const users = useAuthStore(state => state.users);
  const movies = useMovieStore(state => state.movies);

  const stats = [
    { title: 'Total Movies', value: movies.length, icon: Film, color: 'text-blue-500', bg: 'bg-blue-500/10' },
    { title: 'Total Users', value: users.filter(u => u.role === 'user').length, icon: Users, color: 'text-green-500', bg: 'bg-green-500/10' },
    { title: 'Categories', value: useMovieStore.getState().categories.length, icon: PlayCircle, color: 'text-purple-500', bg: 'bg-purple-500/10' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white">Dashboard</h1>
        <p className="text-zinc-400 mt-1">Platform overview and statistics</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-zinc-900 border border-zinc-800 rounded-xl p-6 flex items-center gap-4">
            <div className={`p-4 rounded-lg ${stat.bg}`}>
              <stat.icon className={`w-8 h-8 ${stat.color}`} />
            </div>
            <div>
              <p className="text-sm font-medium text-zinc-400">{stat.title}</p>
              <h3 className="text-3xl font-bold text-white mt-1">{stat.value}</h3>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
          <h2 className="text-xl font-bold text-white flex items-center gap-2 mb-4">
            <Clock className="w-5 h-5 text-red-500" />
            Recent Movies Added
          </h2>
          <div className="space-y-4">
            {movies.slice(-5).reverse().map(movie => (
              <div key={movie.id} className="flex items-center gap-4 p-3 bg-zinc-950 rounded-lg">
                <img src={movie.posterUrl} alt={movie.title} className="w-12 h-16 object-cover rounded" />
                <div>
                  <h4 className="text-white font-medium">{movie.title}</h4>
                  <p className="text-sm text-zinc-400">{movie.releaseYear} • {movie.category}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
          <h2 className="text-xl font-bold text-white flex items-center gap-2 mb-4">
            <Users className="w-5 h-5 text-red-500" />
            Recent Users
          </h2>
          <div className="space-y-4">
            {users.filter(u => u.role === 'user').slice(-5).reverse().map(user => (
              <div key={user.id} className="flex items-center justify-between p-4 bg-zinc-950 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-zinc-800 rounded-full flex items-center justify-center">
                    <span className="text-lg font-bold text-white">{user.username.charAt(0).toUpperCase()}</span>
                  </div>
                  <span className="text-white font-medium">{user.username}</span>
                </div>
                <span className="text-xs text-zinc-500">ID: {user.id}</span>
              </div>
            ))}
            {users.filter(u => u.role === 'user').length === 0 && (
              <p className="text-zinc-500 text-sm">No regular users registered yet.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
