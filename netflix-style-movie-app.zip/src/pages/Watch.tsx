import { useEffect, useRef, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useMovieStore } from '../store/useMovieStore';
import { useAuthStore } from '../store/useAuthStore';
import { ArrowLeft, Play, Pause, Volume2, VolumeX, Maximize, Settings } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Watch() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const movie = useMovieStore(state => state.movies.find(m => m.id === id));
  const updateProgress = useAuthStore(state => state.updateProgress);
  const currentUser = useAuthStore(state => state.currentUser);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showControls, setShowControls] = useState(true);
  const [duration, setDuration] = useState(0);
  
  let controlsTimeout: NodeJS.Timeout;

  useEffect(() => {
    if (!movie) {
      navigate('/');
      return;
    }

    // Load previous progress
    if (currentUser) {
      const savedProgress = currentUser.continueWatching.find(cw => cw.movieId === id);
      if (savedProgress && videoRef.current) {
        // Only seek if we have a valid progress and it's not the end
        if (savedProgress.progress > 0 && savedProgress.progress < 95) {
            const timeToSeek = (savedProgress.progress / 100) * (videoRef.current.duration || 0);
            if (isFinite(timeToSeek)) {
                videoRef.current.currentTime = timeToSeek;
            }
        }
      }
    }
  }, [id, movie, currentUser, navigate]);

  const handleMouseMove = () => {
    setShowControls(true);
    clearTimeout(controlsTimeout);
    controlsTimeout = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  };

  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const toggleFullScreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
    } else {
      document.exitFullscreen();
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const currentProgress = (videoRef.current.currentTime / videoRef.current.duration) * 100;
      setProgress(currentProgress);
      
      // Save progress every few seconds (throttled by Zustand, but let's do it simply)
      if (Math.floor(videoRef.current.currentTime) % 5 === 0 && id) {
        updateProgress(id, currentProgress);
      }
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = (time / 100) * videoRef.current.duration;
      setProgress(time);
    }
  };

  const formatTime = (seconds: number) => {
    if (!isFinite(seconds)) return "00:00";
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  if (!movie) return null;

  return (
    <div 
      ref={containerRef}
      className="fixed inset-0 bg-black z-[100] flex items-center justify-center"
      onMouseMove={handleMouseMove}
      onMouseLeave={() => isPlaying && setShowControls(false)}
    >
      <video
        ref={videoRef}
        src={movie.videoUrl}
        className="w-full h-full"
        autoPlay
        onPlay={() => setIsPlaying(true)}
        onPause={() => setIsPlaying(false)}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={() => {
            if(videoRef.current) {
                setDuration(videoRef.current.duration);
                // Try to set initial progress here if needed
                const savedProgress = currentUser?.continueWatching.find(cw => cw.movieId === id);
                if (savedProgress && savedProgress.progress > 0 && savedProgress.progress < 95) {
                    videoRef.current.currentTime = (savedProgress.progress / 100) * videoRef.current.duration;
                }
            }
        }}
        onClick={togglePlay}
      />

      <div className={cn("absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/60 transition-opacity duration-300 flex flex-col justify-between", showControls ? "opacity-100" : "opacity-0")}>
        <div className="p-6 flex items-center gap-4">
          <button 
            onClick={() => navigate(-1)}
            className="text-white hover:text-red-500 transition-colors"
          >
            <ArrowLeft className="w-8 h-8" />
          </button>
          <h1 className="text-2xl font-bold text-white drop-shadow-md">{movie.title}</h1>
        </div>

        <div className="p-6 space-y-4">
          <div className="flex items-center gap-4">
            <span className="text-white text-sm font-medium">{formatTime(videoRef.current?.currentTime || 0)}</span>
            <input
              type="range"
              min="0"
              max="100"
              value={progress || 0}
              onChange={handleSeek}
              className="flex-1 h-1 bg-zinc-600 rounded-lg appearance-none cursor-pointer accent-red-600 focus:outline-none"
            />
            <span className="text-white text-sm font-medium">{formatTime(duration)}</span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <button onClick={togglePlay} className="text-white hover:text-red-500 transition-colors">
                {isPlaying ? <Pause className="w-8 h-8" /> : <Play className="w-8 h-8" />}
              </button>
              <button onClick={toggleMute} className="text-white hover:text-red-500 transition-colors">
                {isMuted ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
              </button>
            </div>
            
            <div className="flex items-center gap-6">
              <button className="text-white hover:text-red-500 transition-colors">
                <Settings className="w-6 h-6" />
              </button>
              <button onClick={toggleFullScreen} className="text-white hover:text-red-500 transition-colors">
                <Maximize className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
